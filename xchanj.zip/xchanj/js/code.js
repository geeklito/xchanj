
function variable(){
	bnc=$("#bnc").text();
	buh= $("#buh").text();
	uni=$("#uni").text();
	soge=$("#soge").text();
	capi=$("#capi").text();
	mont=$("#mont").val();
	choix=$("#choix").val();
	us=$("#us").val();
	gde=$("#gde").val();
}

$(".badge").hide();

$("#choix").change(function(){ 
 variable();
 calcul(mont,choix); 
});

function calcul(mont,ch)
{
	variable();
	if(ch==="us")
	{ 
        $("#bnc").text(mont*bnc); 
		buh= $("#buh").text(mont*buh);
		uni=$("#uni").text(mont*uni);
		soge=$("#soge").text(mont*soge);
		capi=$("#capi").text(mont*capi);		
		$(".badge").show();
		 
	}else if(ch==="gde"){
		     $("#bnc").text(mont/bnc); 
		buh= $("#buh").text(mont/buh);
		uni=$("#uni").text(mont/uni);
		soge=$("#soge").text(mont/soge);
		capi=$("#capi").text(mont/capi);		
		$(".badge").show();
	}else{
		alert("veuillez choisir une conversion");
	}
}



